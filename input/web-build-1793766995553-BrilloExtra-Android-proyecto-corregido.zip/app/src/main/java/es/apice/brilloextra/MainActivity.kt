package es.apice.brilloextra

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "Brillo Extra"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Oscurece la pantalla por debajo del brillo mínimo del móvil mediante una capa negra."
            textSize = 16f
            setPadding(0, 18, 0, 24)
        })
        val permission = Button(this).apply {
            text = "1 · Permitir mostrar sobre otras apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        root.addView(permission)
        root.addView(Button(this).apply {
            text = "2 · Activar filtro oscuro"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, DimService::class.java))
                    Toast.makeText(this@MainActivity, "Filtro activado. Ajusta la intensidad desde la burbuja.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this@MainActivity, "Concede primero el permiso de superposición.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Desactivar filtro"
            setOnClickListener { stopService(Intent(this@MainActivity, DimService::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "\nNota: el filtro oscurece la imagen, no reduce físicamente la iluminación del panel."
            textSize = 13f
        })
        setContentView(root)
    }
}
