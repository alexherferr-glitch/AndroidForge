package es.apice.brilloextra

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

class DimService : Service() {
    private lateinit var wm: WindowManager
    private var shade: View? = null
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var alpha = 0.45f

    override fun onCreate() {
        super.onCreate()
        val channel = "brillo_extra"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "Filtro de pantalla", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channel)
            .setContentTitle("Brillo Extra activo")
            .setContentText("Toca la burbuja para ajustar o cerrar el filtro")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        val bubble = TextView(this).apply {
            text = "☾"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC333333.toInt())
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        val p = WindowManager.LayoutParams(130, 130, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; y = 260 }
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var downX=0f; var downY=0f; var startX=0; var startY=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.rawX-downX)>8 || kotlin.math.abs(e.rawY-downY)>8) moved=true
                        p.x=startX+(downX-e.rawX).roundToInt(); p.y=startY+(e.rawY-downY).roundToInt()
                        wm.updateViewLayout(v,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if(!moved) v.performClick(); return true }
                }; return false
            }
        })
        wm.addView(bubble,p)
        // The black layer itself is below the controls and does not intercept touches.
        shade = View(this).apply { setBackgroundColor(0xFF000000.toInt()); alpha=alpha }
        val sp = WindowManager.LayoutParams(-1,-1,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP; alpha=1f }
        // Add shade first, then bubble (bubble remains clickable).
        wm.addView(shade,sp)
        shade?.alpha=alpha
        // Reorder bubble above shade by bringing it to front is not guaranteed; panel is added later.
    }

    private fun showPanel() {
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(24,18,24,18); setBackgroundColor(0xEE222222.toInt())
        }
        box.addView(TextView(this).apply { text="Intensidad del filtro"; setTextColor(-1); textSize=17f })
        val seek=SeekBar(this).apply { max=90; progress=(alpha*100).roundToInt(); setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?, value:Int, user:Boolean) { alpha=value/100f; shade?.alpha=alpha }
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) {}
        })
        box.addView(seek)
        box.addView(Button(this).apply { text="Cerrar controles"; setOnClickListener { hidePanel() } })
        box.addView(Button(this).apply { text="Apagar filtro"; setOnClickListener { stopSelf() } })
        val p=WindowManager.LayoutParams(650,WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.CENTER }
        wm.addView(box,p); panel=box
    }
    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel=null }
    override fun onDestroy() {
        panel?.let { wm.removeView(it) }; shade?.let { wm.removeView(it) }
        super.onDestroy()
    }
    override fun onBind(intent:Intent?): IBinder? = null
}
