package es.apice.brilloextra

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

class DimService : Service() {
    private lateinit var windowManager: WindowManager
    private var shade: View? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var shadeParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var filterAlpha = 0.45f

    override fun onCreate() {
        super.onCreate()
        createNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showShade()
        showBubble()
    }

    private fun createNotification() {
        val channelId = "brillo_extra"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Filtro de pantalla", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setContentTitle("Brillo Extra activo")
            .setContentText("Usa la burbuja para ajustar o apagar el filtro")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(7, notification)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun showShade() {
        shade = View(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            alpha = filterAlpha
        }
        shadeParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(shade, shadeParams)
    }

    private fun showBubble() {
        val button = TextView(this).apply {
            text = "☾"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD333333.toInt())
            contentDescription = "Ajustes de Brillo Extra"
            setOnClickListener {
                if (panel == null) showPanel() else hidePanel()
            }
        }
        val params = WindowManager.LayoutParams(
            dp(52), dp(52), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(180)
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.x
                        startY = params.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(event.rawX - downX) > dp(6) || abs(event.rawY - downY) > dp(6)) {
                            moved = true
                        }
                        params.x = startX + (downX - event.rawX).roundToInt()
                        params.y = startY + (event.rawY - downY).roundToInt()
                        windowManager.updateViewLayout(view, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) view.performClick()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })
        bubble = button
        bubbleParams = params
        // La capa oscura se añade primero para que la burbuja quede siempre visible encima.
        windowManager.addView(button, params)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(0xF0222222.toInt())
        }
        box.addView(TextView(this).apply {
            text = "Intensidad del filtro"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
        })
        val seek = SeekBar(this).apply {
            max = 90
            progress = (filterAlpha * 100).roundToInt().coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    filterAlpha = value / 100f
                    shade?.alpha = filterAlpha
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        box.addView(seek)
        box.addView(Button(this).apply {
            text = "Cerrar controles"
            setOnClickListener { hidePanel() }
        })
        box.addView(Button(this).apply {
            text = "Apagar filtro"
            setOnClickListener { stopSelf() }
        })
        val params = WindowManager.LayoutParams(
            dp(290), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        panel = box
        windowManager.addView(box, params)
    }

    private fun hidePanel() {
        panel?.let { view ->
            if (view.isAttachedToWindow) windowManager.removeView(view)
        }
        panel = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        hidePanel()
        bubble?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        shade?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        bubble = null
        shade = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
